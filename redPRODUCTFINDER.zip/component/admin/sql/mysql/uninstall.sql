SET FOREIGN_KEY_CHECKS=0;

DROP TABLE `#__redproductfinder_types`;

DROP TABLE IF EXISTS `#__redproductfinder_associations`;
DROP TABLE IF EXISTS `#__redproductfinder_association_tag`;
DROP TABLE IF EXISTS `#__redproductfinder_dependent_tag`;
DROP TABLE IF EXISTS `#__redproductfinder_filters`;
DROP TABLE IF EXISTS `#__redproductfinder_forms`;
DROP TABLE IF EXISTS `#__redproductfinder_tags`;
DROP TABLE IF EXISTS `#__redproductfinder_tag_type`;
DROP TABLE IF EXISTS `#__redproductfinder_types`;

SET FOREIGN_KEY_CHECKS=1;
