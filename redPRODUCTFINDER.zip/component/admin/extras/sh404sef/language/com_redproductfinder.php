<?php
  if (!defined('_JEXEC')) die('Direct Access to this location is not allowed.');
  // {shSourceVersionTag: Version x - 2007-09-20} 
  
  // english
  $sh_LANG['en']['_COM_SEF_REDPRODUCTFINDER'] = 'redPRODUCTFINDER';
  $sh_LANG['en']['_COM_SEF_TITLE_REDPRODUCTFINDER'] = 'redPRODUCTFINDER';
  // dutch
  $sh_LANG['nl']['_COM_SEF_REDPRODUCTFINDER'] = 'redPRODUCTFINDER';
  $sh_LANG['nl']['_COM_SEF_TITLE_REDPRODUCTFINDER'] = 'redPRODUCTFINDER';
?>